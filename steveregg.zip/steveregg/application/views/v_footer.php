<footer>
    <a href="https://www.malasngoding.com">MalasNgoding</a>
</footer>
</div>

</body>

</html>