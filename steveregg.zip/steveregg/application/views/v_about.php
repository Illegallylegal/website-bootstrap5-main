<section>
    <h1><?php echo $judul ?></h1>
    <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Non repellat ipsum repudiandae perferendis
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Excepturi eveniet illo modi inventore soluta
        numquam quia itaque natus, ratione nostrum, quaerat deleniti dolorem dignissimos eligendi est quidem
        quos iste laboriosam?
        facere molestias, et commodi ea minima, voluptatem explicabo magnam itaque! Possimus porro adipisci
        maxime, nemo ea rem.
        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dolores harum fuga ipsa voluptatem ipsum
        numquam tempore, accusantium est, optio reprehenderit facilis fugiat eum cupiditate doloremque
        asperiores mollitia dolore eos at!
        lore,
    </p>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Explicabo autem porro laboriosam accusamus ut,
        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quidem deserunt consectetur fuga dolore?
        Quaerat laudantium ut molestiae repudiandae. Qui eaque rerum delectus officiis amet? Quis voluptatibus
        quidem sit ipsum delectus!
        iste ipsa amet natus cupiditate tempore! Qui consequatur dolores fugit sint libero architecto optio
        aliquam soluta!</p>
    <p>tutorial codeigniter malasngoding.com</p>
</section>